insert into Teacher(id,name,dept) values(1,'Indu','CSE');
insert into Student(id,stuname,rollno,teacher_id) values(101,'Nikhil','962318104030',1)
insert into Student(id,stuname,rollno,teacher_id) values(100,'Rajubai','962318104029',1)