package com.example.teacherstudent.TeacherStudent.Repository;

public interface TeacherRepo {

}
